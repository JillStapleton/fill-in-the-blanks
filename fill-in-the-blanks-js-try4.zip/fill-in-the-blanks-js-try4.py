'''This program is a fill in the blanks quiz game.
   The first section defines the text of the quizes and the answer keys
   The second section contains the helper functions for the program
   The third section contains the "run_quiz" function which executes all of the helper functions.
 '''
 
#Section 1 - The text of the quizzes, and the answer list for each level are defined
quizzes = {
	"level_1":"A __1__ is created with the def keyword. You specify the inputs a function takes by adding __2__ separated by commas between the parentheses. Functions by default return __3__ if you don't specify the value to return. Parameters can be standard data types such as string, number, dictionary, tuple, and __4__ or can be more complicated such as objects and lambda function.",
	"level_2":"Strings are any sequence of __1__ enclosed by single or double __2__. The answers you give in this quiz are translated into strings in python. There are a number of useful things you can do with strings... if you want to add strings together, you can __3__ them. A concatenated string looks like this: 'hello' + 'world' returns 'hello world'. You can't concatenate a number as a number, but you can turn a number into a string like this: str(3) returns '3'. One of the most annoying things about a strings to a new programmer is that when you're indexing strings, the first letter is indexed at __4__. This is just not intuitive. Another really awkward thing about strings is when you try to extract a sub sequence. The sequence is identified by [n1,n2] where the ns are the indexes of the beginning and end of your extraction. The annoying thing here is that the first number is inclusive, but the second is not. Once you get your head around these two confusing bits, working with strings gets pretty easy.", 
	"level_3": "If, while and for are powerful basic concepts that we use in python. You can use an If statement to evaluate whether a test expression is __1__. If it is, the computer executes the code contained in the If block. if not, then the computer skips that code and moves on to the next thing. While is a loop. You can use it to execute the same block of code over and over again while the test expression is true. Once the test expression is __2__, the computer gets off of the hamster wheel and moves on to the next bit of code. It's important in a while loop to set it up so that at some point the test expression becomes false and your computer is allowed to move on. For is a cute little idea. A For loop does something for each __3__ in a list and then moves on. It's a nice way to do the same thing to every element without needing to worry about setting up an exit strategy as you do for a __4__ loop."}

answers = {
	"level_1_answers": ["function","parameters","None","list"],
	"level_2_answers":["characters","quotes","concatenate","0"],
	"level_3_answers":["true","false","element","while"]
}

#Section 2: helper functions are defined
def choose_level():
	'''
	# User chooses a level: easy, medium or hard.
	# if the user doesn't choose a valid value, a message prints and the program ends
	# level,quiz, and answer_key variables are defined
	'''
	level=input("Choose a level: easy, medium, or hard:")
	if level=="easy":
		quiz=quizzes["level_1"]
		answer_key=answers["level_1_answers"]
	elif level=="medium":
			quiz=quizzes["level_2"]
			answer_key=answers["level_2_answers"]
	elif level=="hard":
			quiz=quizzes["level_3"]
			answer_key=answers["level_3_answers"]
	else:
		print("Sorry, your level choice was not understood. Please play again.")
		exit()
	return level,quiz,answer_key

def instructions(quiz):	
	'''
	#Fill in the blanks quiz prints, and user is given instructions.
	#Parameter: quiz comes from the choose_level function which returns the correct quiz for the level the user has chosen.
	'''	
	print (quiz+"\n"+"\n"+"Instructions: What word best fills the first blank?""\n")

def check_answers(answer_num,answer_key):
	'''
	# User enters an answer, and the answer is checked against the quiz's answer key
	# if correct, the program moves on. If incorrect, the user is prompted again
	# user is given 4 tries
	#user_answer variable is defined
	#Parameter: answer_num comes from the run_quiz function. It is used to cycle through the user's answers.
	#Parameter: answer_key comes from the choose_level function which returns the correct answer_key for the level the user has chosen. It is used to check the user's answers.
	'''
	tries=1
	#user inputs answers
	user_answer=input("Answer:")
	while tries<5:
		if user_answer==answer_key[answer_num-1]:
			print ("Answer is correct")
			break
		else: 
			print ("Answer is not correct, please try again.")
		user_answer=input("Answer:")
		tries=tries+1
		if tries == 5:
			print("Sorry, you've exhausted the number of chances for this answer. Time to go back to the books? Please try again later")
			exit()
	print ("")
	return user_answer

def fill_blanks(answer_num,quiz,user_answer):
	'''
	#quiz paragraph is printed with the users' answers filled in
	#quiz variable is changed to include the correct answers the user has given
	#Parameter: answer_num comes from the run_quiz function. It cycles through numbers 1-4 so that each answer is checked.
	#Parameter: quiz - the first iteration of quiz comes from the choose_level function which returns the correct quiz for the level the user has chosen.
	#Parameter: quiz - subsequent iterations of quiz come from the fill_blanks function - with the user answers that have already been given subtituted for blanks.
	#Parameter: user_answer comes from the check_answers function. It is used to cycle through the user's answers.
	'''
	answered=""
	while len(quiz)>0:
		character=quiz[0]
		blank=quiz[0:5]
		if character != "_":
			answered=answered+character
			quiz=quiz[1:]
		else:
			quiz=quiz[5:]
			answered=answered+user_answer+quiz
			quiz=[]
	print (answered)
	quiz=answered
	return quiz

def next_question(answer_num):
	'''
	#if the user isn't done with the quiz yet, they are prompted for the next answer
	#if the quiz is over, a congratulation statement prints
	#Parameter: user_answer comes from the check_answers function. It is used to cycle through the user's answers.
	'''
	print ("")
	if answer_num<4:
		print ("What word best fills the next blank?")
		print ("")
	else:
		print ("Congratulations, you have successfully completed this quiz.")

def run_quiz():
	'''
	#everything is put together. 
	#Every function with local variables that are used as parameters is called.
	#Helper functions are called with the appropriate variables passed in.
	#The variable answer_num guides the program through each answer #1-4
	'''
	level,quiz,answer_key=choose_level()
	instructions(quiz)
	answer_num=1
	while answer_num<len(answer_key)+1:
		user_answer=check_answers(answer_num,answer_key)
		quiz=fill_blanks(answer_num,quiz,user_answer)
		next_question(answer_num)
		answer_num=answer_num+1

run_quiz()
